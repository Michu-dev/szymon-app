﻿function Class_Change(ObjectID, Class)
{
    var Object = document.getElementById(ObjectID);
    Object.className = Class;
}